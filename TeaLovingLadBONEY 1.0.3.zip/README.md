# BONEY
BONEY (short for "Bunch of New Eyes, Yeah) is a mod for Webfishing that adds around 130 new eyes to customize your characters with!

Silly, serious, references, fancy, jokes, simple... This mod offers it all!

![alt text](https://imgur.com/mjsqK21.png)

![alt text](https://imgur.com/g4AGYIu.png)
